"""
train.py - trains the phishing-URL model and saves it to model.pkl

Run:  python train.py
(detector.py also calls train() automatically if model.pkl is missing or
 can't be loaded, e.g. when it was made with a different scikit-learn version.)
"""

import os
import pickle

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import cross_val_score, train_test_split

from features import FEATURE_NAMES, extract_features

BASE = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE, "dataset.csv")
MODEL_PATH = os.path.join(BASE, "model.pkl")

# Lets you drop in popular public datasets that label rows 'good'/'bad' etc.
_PHISH_WORDS = {"1", "bad", "phishing", "malicious", "phish", "unsafe"}


def load_dataset(path=DATASET_PATH):
    data = pd.read_csv(path)
    data.columns = [c.strip().lower() for c in data.columns]
    if "url" not in data.columns or "label" not in data.columns:
        raise ValueError("dataset.csv needs two columns: url,label")

    data = data.dropna(subset=["url", "label"]).drop_duplicates(subset="url")
    data["label"] = data["label"].astype(str).str.strip().str.lower().isin(_PHISH_WORDS).astype(int)
    return data


def train(verbose=True):
    data = load_dataset()
    X = [extract_features(u) for u in data["url"]]
    y = data["label"].tolist()

    if verbose:
        print(f"Dataset: {len(data)} URLs  "
              f"(legit={y.count(0)}, phishing={y.count(1)})")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        min_samples_leaf=2,          # stops the trees from memorising single URLs
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    if verbose:
        predictions = model.predict(X_test)
        print("\nHeld-out test accuracy:", round(accuracy_score(y_test, predictions), 4))
        print(classification_report(y_test, predictions,
                                    target_names=["legitimate", "phishing"]))
        print("Confusion matrix [rows = truth, cols = prediction]:")
        print(confusion_matrix(y_test, predictions))

        scores = cross_val_score(
            RandomForestClassifier(n_estimators=100, min_samples_leaf=2,
                                   class_weight="balanced", random_state=42, n_jobs=-1),
            X, y, cv=5)
        print(f"\n5-fold cross-validation: {scores.mean():.4f} (+/- {scores.std():.4f})")

        print("\nWhat the model pays attention to:")
        ranked = sorted(zip(FEATURE_NAMES, model.feature_importances_), key=lambda t: -t[1])
        for name, imp in ranked[:8]:
            print(f"  {name:22s} {imp:.3f}")

    # Final model: learn from ALL the data
    model.fit(X, y)

    with open(MODEL_PATH, "wb") as file:
        pickle.dump(model, file)
    if verbose:
        print("\nModel trained and saved successfully!")
    return model


if __name__ == "__main__":
    train()
