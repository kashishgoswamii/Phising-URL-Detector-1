"""
build_dataset.py - creates dataset.csv  (columns: url,label   0 = legitimate, 1 = phishing)

WHY THIS EXISTS
The original dataset.csv had only 11 URLs, so the model just memorised them.
This script generates a few thousand varied examples so the model has to learn
real patterns (brand imitation, IP hosts, odd TLDs, keyword stuffing ...).

IMPORTANT: this data is SYNTHETIC (generated from patterns). It is good for a
class project / demo, but for serious accuracy you should replace dataset.csv
with a real dataset (PhishTank, Kaggle "Phishing Site URLs", UCI phishing ...).
train.py works with any CSV that has a url column and a label column.

Run:  python build_dataset.py
"""

import csv
import os
import random
import string

random.seed(42)
N_PER_CLASS = 2500
BASE = os.path.dirname(os.path.abspath(__file__))

WORDS = ["world", "asia", "india", "news", "tech", "how", "to", "fix", "python", "error",
         "best", "phones", "under", "guide", "review", "budget", "laptop", "career",
         "college", "exam", "result", "notes", "engineering", "machine", "learning",
         "tutorial", "beginners", "cricket", "match", "score", "recipe", "travel", "delhi",
         "mumbai", "gadgets", "offers", "sale", "festival", "movie", "series", "music",
         "health", "fitness", "finance", "stocks", "startup", "ai", "security"]
FILLER = ["alpha", "nova", "smart", "fast", "cloud", "bright", "prime", "zen", "unity",
          "global", "royal", "metro", "pixel", "orbit", "delta", "vista", "swift", "pure",
          "omni", "blue", "red", "star", "sky", "net", "web", "online", "service", "center"]


def token(n):
    return "".join(random.choices(string.ascii_letters + string.digits, k=n))


def slug(n):
    return "-".join(random.sample(WORDS, n))


# ----------------------------------------------------------------------------
# LEGITIMATE URLs
# ----------------------------------------------------------------------------

LEGIT_SITES = [
    "google.com", "youtube.com", "wikipedia.org", "github.com", "stackoverflow.com",
    "amazon.in", "amazon.com", "flipkart.com", "microsoft.com", "apple.com", "bbc.co.uk",
    "nytimes.com", "linkedin.com", "reddit.com", "twitter.com", "instagram.com",
    "facebook.com", "netflix.com", "paypal.com", "sbi.co.in", "hdfcbank.com",
    "icicibank.com", "paytm.com", "phonepe.com", "irctc.co.in", "india.gov.in",
    "incometax.gov.in", "uidai.gov.in", "aktu.ac.in", "mit.edu", "stanford.edu",
    "python.org", "pypi.org", "npmjs.com", "medium.com", "quora.com", "zoom.us",
    "dropbox.com", "spotify.com", "swiggy.com", "zomato.com", "hotstar.com", "myntra.com",
    "naukri.com", "w3schools.com", "geeksforgeeks.org", "leetcode.com", "kaggle.com",
    "mozilla.org", "cloudflare.com", "wordpress.com", "bing.com", "yahoo.com",
    "duckduckgo.com", "ebay.com", "walmart.com", "cnn.com", "theguardian.com",
    "indiatimes.com", "hindustantimes.com", "ndtv.com", "thehindu.com", "indianexpress.com",
    "coursera.org", "udemy.com", "khanacademy.org", "nptel.ac.in", "canva.com", "figma.com",
    "notion.so", "slack.com", "atlassian.com", "adobe.com", "oracle.com", "ibm.com",
    "intel.com", "nvidia.com", "samsung.com", "mi.com", "oneplus.com", "airtel.in",
    "jio.com", "bsnl.co.in", "makemytrip.com", "goibibo.com", "olacabs.com", "uber.com",
    "airbnb.com", "booking.com", "tripadvisor.com", "imdb.com", "twitch.tv", "discord.com",
    "telegram.org", "whatsapp.com", "gmail.com", "outlook.com", "live.com", "office.com",
    "onlinesbi.sbi", "axisbank.com", "kotak.com", "pnbindia.in", "bankofbaroda.in",
    # real sites that "look odd" (hyphens / digits) so the model doesn't over-trust them
    "t-mobile.com", "coca-cola.com", "7-eleven.com", "1mg.com", "99acres.com", "3m.com",
    "e-pay.co.in", "my-gov.in", "snapchat.com", "binance.com", "coinbase.com",
]
LEGIT_SUBS = [""] * 3 + ["www."] * 8 + ["accounts.", "mail.", "m.", "support.", "help.",
              "blog.", "developer.", "docs.", "news.", "store.", "login.", "my.", "app.",
              "portal.", "shop.", "en.", "in.", "www2."]
LEGIT_KW_PATHS = ["login", "signin", "account", "accounts/settings", "support",
                  "help/contact", "billing", "password/reset", "verify-email",
                  "security", "update-profile", "secure/checkout"]
LEGIT_LOGIN_PAGES = [  # real login pages: a model must not flag 'login' on its own
    "https://accounts.google.com/signin/v2/identifier",
    "https://login.microsoftonline.com/common/oauth2/authorize",
    "https://www.paypal.com/signin", "https://www.facebook.com/login/",
    "https://github.com/login", "https://www.linkedin.com/login",
    "https://netbanking.hdfcbank.com/netbanking/",
    "https://retail.onlinesbi.sbi/retail/login.htm",
    "https://www.instagram.com/accounts/login/", "https://appleid.apple.com/sign-in",
    "https://www.amazon.in/ap/signin", "https://secure.bankofamerica.com/login/sign-in/signOn.go",
    "https://login.live.com/", "https://www.netflix.com/login", "https://twitter.com/i/flow/login",
    "https://www.icicibank.com/personal-banking/insta-banking/internet-banking",
    "https://www.irctc.co.in/nget/train-search", "https://myaccount.google.com/security",
    "https://support.microsoft.com/en-us/account-billing",
    "https://www.flipkart.com/account/login?ret=%2F",
]


def legit_path():
    r = random.random()
    if r < .18:
        return ""
    if r < .30:
        return "/" + random.choice(["about", "contact", "pricing", "careers", "products",
                                    "explore", "home", "downloads", "docs"])
    if r < .45:
        return f"/{slug(random.randint(2, 6))}-{random.randint(10000, 99999999)}"
    if r < .55:
        return f"/search?q={'+'.join(random.sample(WORDS, 2))}&page={random.randint(1, 9)}"
    if r < .65:
        return "/wiki/" + "_".join(w.title() for w in random.sample(WORDS, 2))
    if r < .73:
        return f"/watch?v={token(11)}"
    if r < .80:
        return f"/questions/{random.randint(100000, 99999999)}/{slug(random.randint(3, 7))}"
    if r < .86:
        return f"/dp/B0{token(8).upper()}?ref=nav_{random.randint(1, 99)}&tag={slug(2)}-21"
    if r < .90:
        return f"/@{random.choice(WORDS)}{random.randint(1, 99)}/{slug(random.randint(3, 6))}-{token(10)}"
    if r < .95:
        return "/" + random.choice(LEGIT_KW_PATHS)
    return (f"/{random.choice(WORDS)}/{random.choice(WORDS)}/{slug(random.randint(2, 5))}.html"
            f"?id={random.randint(1, 99999)}&ref={random.choice(WORDS)}")


def legit_url():
    if random.random() < .04:
        return random.choice(LEGIT_LOGIN_PAGES)
    scheme = "https" if random.random() < .92 else "http"
    return f"{scheme}://{random.choice(LEGIT_SUBS)}{random.choice(LEGIT_SITES)}{legit_path()}"


# ----------------------------------------------------------------------------
# PHISHING URLs
# ----------------------------------------------------------------------------

PH_BRANDS = ["paypal", "google", "amazon", "microsoft", "apple", "facebook", "instagram",
             "netflix", "whatsapp", "linkedin", "flipkart", "paytm", "phonepe", "sbi",
             "hdfcbank", "icicibank", "irctc", "airtel", "youtube", "twitter", "dhl",
             "fedex", "incometax", "ebay", "adobe", "spotify", "dropbox", "telegram",
             "snapchat", "binance", "coinbase", "jio"]
PH_KW = ["login", "signin", "verify", "secure", "account", "update", "confirm", "password",
         "wallet", "billing", "suspended", "unlock", "otp", "kyc", "refund", "claim",
         "reward", "support", "recover", "validate", "payment", "alert", "security",
         "netbanking"]
TLD_BAD = ["xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "work", "support", "icu",
           "buzz", "cam", "loan", "rest", "monster", "site", "online", "shop", "live",
           "info", "store", "cc", "link"]
TLD_OK = ["com", "net", "org", "in", "co.in", "info"]
FREE_HOSTS = ["weebly.com", "blogspot.com", "000webhostapp.com", "github.io",
              "firebaseapp.com", "netlify.app", "wixsite.com", "herokuapp.com",
              "web.app", "pages.dev"]


def leet(word):
    swaps = {"o": "0", "l": "1", "e": "3", "a": "4", "i": "1"}
    chars = list(word)
    idx = [i for i, c in enumerate(chars) if c in swaps]
    if not idx:
        return word + "1"
    for i in random.sample(idx, k=min(len(idx), random.randint(1, 2))):
        chars[i] = swaps[chars[i]]
    return "".join(chars)


def phish_path(b, k1, k2):
    r = random.random()
    if r < .15:
        return ""
    if r < .25:
        return "/"
    if r < .40:
        return f"/{k1}"
    if r < .55:
        return f"/{k1}.php"
    if r < .65:
        return f"/{k1}/{k2}.html"
    if r < .78:
        return f"/{b}/{k1}.php?id={random.randint(100, 99999)}&session={token(16)}"
    if r < .86:
        return f"/wp-content/{token(6)}/{k1}.php"
    if r < .93:
        return f"/{token(24)}"
    return f"/index.php?user={token(8)}&{k1}=1"


def random_ip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))


def phish_url():
    b = random.choice(PH_BRANDS)
    k1, k2 = random.sample(PH_KW, 2)
    w = random.choice(WORDS + FILLER)
    tld = random.choice(TLD_BAD) if random.random() < .65 else random.choice(TLD_OK)
    scheme = "https" if random.random() < .55 else "http"
    path = phish_path(b, k1, k2)

    kind = random.choices(range(11), weights=[18, 11, 10, 8, 6, 8, 10, 3, 6, 12, 8])[0]
    if kind == 0:      # brand-keyword-hyphen:  paypal-secure-login.xyz
        host = f"{b}-{k1}-{k2}.{tld}" if random.random() < .6 else f"{b}-{k1}.{tld}"
    elif kind == 1:    # brand.com.evil.tld
        host = f"{b}.com.{k1}-{w}.{tld}"
    elif kind == 2:    # brand as sub-domain
        host = f"{b}.{k1}.{w}-{k2}.{tld}"
    elif kind == 3:    # login.brand.evil.tld
        host = f"{k1}.{b}.{w}{random.randint(1, 999)}.{tld}"
    elif kind == 4:    # raw IP address
        scheme = "http" if random.random() < .85 else "https"
        host = random_ip()
        if random.random() < .15:
            host += f":{random.choice([8080, 8000, 8888, 4443])}"
    elif kind == 5:    # user@host trick
        host = f"{b}.com@{w}{random.randint(1, 99)}.{tld}"
        path = f"/{k1}"
    elif kind == 6:    # typo-squatting:  paypa1, g00gle ...
        host = f"{leet(b)}.{random.choice(TLD_OK)}" if random.random() < .5 else f"{leet(b)}-{k1}.{tld}"
    elif kind == 7:    # punycode look-alike
        host = f"xn--{b[:-1]}-{token(3).lower()}.{random.choice(['com', 'net', tld])}"
    elif kind == 8:    # free hosting
        host = f"{b}-{k1}.{random.choice(FREE_HOSTS)}"
    elif kind == 9:    # random junk domain + long path
        host = f"{w}{random.randint(10, 9999)}.{tld}"
        path = f"/{token(12)}/{k1}.html?id={random.randint(1, 99999)}&token={token(20)}"
    else:              # generic bait, no brand
        host = f"{k1}-{k2}-{w}.{tld}"
    return f"{scheme}://{host}{path}"


# ----------------------------------------------------------------------------

ORIGINAL_ROWS = [   # the 11 rows from the original project - kept
    ("https://www.google.com", 0), ("https://www.wikipedia.org", 0),
    ("https://www.microsoft.com", 0), ("https://www.python.org", 0),
    ("https://www.github.com", 0), ("https://www.amazon.com", 0),
    ("http://secure-login-verify.example.com", 1), ("http://account-update.example.net", 1),
    ("http://free-prize-claim.example.org", 1), ("http://verify-password.example.com", 1),
    ("http://fake-bank-login.example.net", 1),
]

if __name__ == "__main__":
    rows = {u: l for u, l in ORIGINAL_ROWS}
    counts = {0: sum(1 for l in rows.values() if l == 0), 1: sum(1 for l in rows.values() if l == 1)}
    for label, maker in ((0, legit_url), (1, phish_url)):
        while counts[label] < N_PER_CLASS:
            u = maker()
            if u not in rows:
                rows[u] = label
                counts[label] += 1

    items = list(rows.items())
    random.shuffle(items)
    out = os.path.join(BASE, "dataset.csv")
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["url", "label"])
        w.writerows(items)
    print(f"Wrote {len(items)} URLs to dataset.csv  (legit={counts[0]}, phishing={counts[1]})")
