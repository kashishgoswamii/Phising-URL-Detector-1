"""
detector.py - loads the trained model and checks a URL.
"""

import ipaddress
import os
import pickle
from urllib.parse import urlparse

from features import explain, extract_features

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE, "model.pkl")        # works from ANY folder


def _load_model():
    try:
        with open(MODEL_PATH, "rb") as file:
            return pickle.load(file)
    except Exception:
        # model.pkl missing, or made by a different scikit-learn version:
        # just train a fresh one on this computer.
        from train import train
        return train(verbose=False)


model = _load_model()

PHISHING = "Suspicious / Phishing URL"
SAFE = "Likely Safe URL"


def _is_local_address(url):
    """localhost / 127.x.x.x / ::1 - your own computer, can't be a phishing site."""
    try:
        host = urlparse(url).hostname or ""
    except ValueError:
        return False
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def analyze_url(url):
    """Full analysis: verdict + risk score (0-100) + list of red flags."""
    if _is_local_address(url):
        return {
            "result": SAFE,
            "score": 0,
            "flags": ["This is a local address (your own computer), not a site on the internet"],
        }
    features = extract_features(url)
    risk = float(model.predict_proba([features])[0][1])      # probability of 'phishing'
    return {
        "result": PHISHING if risk >= 0.5 else SAFE,
        "score": round(risk * 100),
        "flags": explain(url),
    }


def check_url(url):
    """Original API: returns just the verdict text."""
    return analyze_url(url)["result"]
