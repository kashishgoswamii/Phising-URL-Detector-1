from flask import Flask, render_template, request
from urllib.parse import urlparse

from detector import analyze_url

app = Flask(__name__)

MAX_URL_LENGTH = 2000


def normalise(raw):
    """Let people type 'google.com' without the https://"""
    raw = raw.strip()
    if raw and "://" not in raw and " " not in raw and "." in raw:
        raw = "https://" + raw
    return raw


@app.route("/", methods=["GET", "POST"])
def home():

    result = None
    score = None
    flags = []
    checked_url = ""

    if request.method == "POST":

        checked_url = normalise(request.form.get("url", ""))

        try:
            parsed = urlparse(checked_url)
            hostname = parsed.hostname
            valid = (
                parsed.scheme in ("http", "https")
                and bool(hostname)
                and len(checked_url) <= MAX_URL_LENGTH
            )
        except ValueError:          # e.g. "http://[abc"  (crashed the original app)
            valid = False

        if not valid:
            result = "Please enter a valid HTTP or HTTPS URL."

        else:
            analysis = analyze_url(checked_url)
            result = analysis["result"]
            score = analysis["score"]
            flags = analysis["flags"]

    return render_template(
        "index.html",
        result=result,
        score=score,
        flags=flags,
        url=checked_url
    )


if __name__ == "__main__":
    app.run(debug=True)
