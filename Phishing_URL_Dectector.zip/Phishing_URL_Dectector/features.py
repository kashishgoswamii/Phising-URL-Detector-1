"""
features.py - turns a URL into numbers the model can learn from.

This file is imported by BOTH train.py and detector.py, so the model is always
trained and used with exactly the same features (in the original project the
function was copy-pasted into two files, which is an easy way to get silent bugs).
"""

import re
from urllib.parse import urlparse

# --------------------------------------------------------------------------
# Knowledge used by the features
# --------------------------------------------------------------------------

# brand name  ->  the real (official) domains of that brand
BRANDS = {
    "paypal": {"paypal.com", "paypal.me", "paypalobjects.com"},
    "google": {"google.com", "google.co.in", "google.co.uk", "gmail.com",
               "googleapis.com", "googleusercontent.com", "googlevideo.com", "gstatic.com"},
    "gmail": {"gmail.com", "google.com"},
    "youtube": {"youtube.com", "youtu.be"},
    "amazon": {"amazon.com", "amazon.in", "amazon.co.uk", "amazon.de", "amazon.ca", "amazonaws.com"},
    "microsoft": {"microsoft.com", "microsoftonline.com", "live.com", "office.com",
                  "outlook.com", "windows.com", "azure.com"},
    "apple": {"apple.com", "icloud.com"},
    "facebook": {"facebook.com", "fb.com", "fb.me", "messenger.com", "fbcdn.net"},
    "instagram": {"instagram.com"},
    "whatsapp": {"whatsapp.com", "whatsapp.net", "wa.me"},
    "netflix": {"netflix.com", "nflxvideo.net"},
    "linkedin": {"linkedin.com", "licdn.com"},
    "twitter": {"twitter.com", "x.com", "t.co"},
    "flipkart": {"flipkart.com"},
    "paytm": {"paytm.com"},
    "phonepe": {"phonepe.com"},
    "sbi": {"sbi.co.in", "onlinesbi.sbi", "onlinesbi.com", "sbicard.com", "sbilife.co.in"},
    "hdfcbank": {"hdfcbank.com"},
    "hdfc": {"hdfcbank.com", "hdfc.com", "hdfclife.com"},
    "icicibank": {"icicibank.com"},
    "icici": {"icicibank.com", "icicilombard.com", "iciciprulife.com"},
    "irctc": {"irctc.co.in", "irctc.com"},
    "airtel": {"airtel.in", "airtel.com"},
    "incometax": {"incometax.gov.in", "incometaxindia.gov.in"},
    "dhl": {"dhl.com"},
    "fedex": {"fedex.com"},
    "ebay": {"ebay.com", "ebay.in", "ebay.co.uk"},
    "adobe": {"adobe.com"},
    "spotify": {"spotify.com", "scdn.co"},
    "dropbox": {"dropbox.com"},
    "telegram": {"telegram.org", "t.me"},
    "snapchat": {"snapchat.com"},
    "binance": {"binance.com"},
    "coinbase": {"coinbase.com"},
    "jio": {"jio.com", "jiopay.com"},
}

# Top-level domains that are very commonly abused for throw-away phishing sites
SUSPICIOUS_TLDS = {
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "work", "support", "icu",
    "buzz", "cam", "loan", "rest", "monster", "zip", "mov", "country", "kim", "men",
    "review", "stream", "download", "party", "trade", "win", "bid", "racing", "date",
}

# Words phishing pages love to put in their address
KEYWORDS = [
    "login", "log-in", "signin", "sign-in", "verify", "verification", "secure",
    "security", "account", "update", "confirm", "banking", "netbanking", "password",
    "passwd", "wallet", "billing", "suspend", "unlock", "otp", "kyc", "refund",
    "claim", "prize", "reward", "gift", "bonus", "free", "support", "helpdesk",
    "recover", "restore", "validate", "authenticate", "payment", "invoice",
    "urgent", "alert",
]

SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly",
              "ow.ly", "rebrand.ly", "shorturl.at", "tiny.cc"}

# "co.in", "co.uk", "gov.in", "ac.in" ... (a tiny stand-in for the public-suffix list)
_SECOND_LEVEL = {"co", "com", "org", "net", "gov", "ac", "edu", "nic", "res"}

# Order matters: the model is trained on this exact order.
FEATURE_NAMES = [
    "url_length",
    "host_length",
    "dots_in_host",
    "subdomain_count",
    "hyphens_in_host",
    "digit_ratio_host",
    "ip_as_host",
    "at_symbol",
    "suspicious_tld",
    "keywords_in_url",
    "keywords_in_host",
    "brand_mismatch",
    "path_length",
    "path_depth",
    "query_length",
    "punycode",
    "odd_port",
    "double_slash_in_path",
]


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

def _parse(url):
    """urlparse that never crashes (e.g. on 'http://[abc')."""
    try:
        return urlparse(str(url).strip())
    except ValueError:
        return None


def _is_ip(host):
    return bool(
        re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", host)
        or re.fullmatch(r"0x[0-9a-f]+|\d{8,10}", host)
        or ":" in host                                   # IPv6
    )


def _strip_www(host):
    return host[4:] if host.startswith("www.") else host


def registered_domain(host):
    """'login.paypal.com' -> 'paypal.com',  'www.sbi.co.in' -> 'sbi.co.in'"""
    host = _strip_www(host)
    if _is_ip(host):
        return host
    parts = host.split(".")
    if len(parts) <= 2:
        return host
    if len(parts[-1]) == 2 and parts[-2] in _SECOND_LEVEL:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def _normalise_leet(text, i_or_l):
    """paypa1 -> paypal,  g00gle -> google,  amaz0n -> amazon"""
    table = {"0": "o", "1": i_or_l, "3": "e", "4": "a", "5": "s", "7": "t"}
    return "".join(table.get(ch, ch) for ch in text)


def _brand_mismatch(host):
    """Returns the brand being imitated, or None.
    A brand is 'imitated' when its name appears in the host name but the site
    is not one of that brand's official domains."""
    host = _strip_www(host)
    if _is_ip(host):
        return None
    reg = registered_domain(host)
    variants = {host, _normalise_leet(host, "l"), _normalise_leet(host, "i")}
    for brand, official in BRANDS.items():
        if reg in official:
            continue
        for h in variants:
            tokens = re.split(r"[.\-_]", h)
            if len(brand) >= 6:
                hit = any(brand in t for t in tokens)      # 'secure-paypal-login' / 'paypalsecure'
            else:
                hit = brand in tokens                       # short names: exact word only (avoids 'pineapple')
            if hit:
                return brand
    return None


def _keyword_hits(text):
    text = text.lower()
    return [k for k in KEYWORDS if k in text]


# --------------------------------------------------------------------------
# Main API
# --------------------------------------------------------------------------

def extract_features(url):
    """URL -> list of numbers, in the order of FEATURE_NAMES."""
    url = str(url).strip()
    p = _parse(url)
    if p is None:                                         # unparseable -> treat as an empty URL
        return [float(len(url))] + [0.0] * (len(FEATURE_NAMES) - 1)

    host = (p.hostname or "").lower()
    host_nw = _strip_www(host)
    reg = registered_domain(host)
    ip = _is_ip(host_nw)
    tld = host_nw.rsplit(".", 1)[-1] if "." in host_nw else ""

    if ip or not host_nw:
        subdomains = 0
    else:
        subdomains = max(0, len(host_nw.split(".")) - len(reg.split(".")))

    try:
        port = p.port
    except ValueError:
        port = None

    features = [
        len(url),
        len(host),
        host.count("."),
        subdomains,
        host.count("-"),
        (sum(ch.isdigit() for ch in host) / len(host)) if host else 0.0,
        int(ip),
        int("@" in p.netloc),                             # '@' only matters in the host part
        int(tld in SUSPICIOUS_TLDS),
        len(_keyword_hits(host + p.path + p.query)),
        len(_keyword_hits(host)),
        int(_brand_mismatch(host) is not None),
        len(p.path),
        p.path.count("/"),
        len(p.query),
        int("xn--" in host),
        int(port not in (None, 80, 443)),
        int("//" in p.path),
    ]
    return [float(f) for f in features]


def explain(url):
    """Human-readable red flags, shown under the verdict in the web page."""
    url = str(url).strip()
    p = _parse(url)
    if p is None:
        return ["The address could not be parsed"]

    host = (p.hostname or "").lower()
    host_nw = _strip_www(host)
    tld = host_nw.rsplit(".", 1)[-1] if "." in host_nw else ""
    reg = registered_domain(host)
    flags = []

    if _is_ip(host_nw):
        flags.append("Uses an IP address instead of a real domain name")
    if "@" in p.netloc:
        flags.append("Contains an '@' symbol, which can hide the real destination")
    brand = _brand_mismatch(host)
    if brand:
        flags.append(f"Looks like it is imitating '{brand}', but the site's actual domain is '{reg}'")
    if tld in SUSPICIOUS_TLDS:
        flags.append(f"Unusual domain ending (.{tld}) often used by throw-away sites")
    if "xn--" in host:
        flags.append("Uses punycode (look-alike international characters)")
    kw = _keyword_hits(host + p.path + p.query)
    if len(kw) >= 2 or (kw and _keyword_hits(host)):
        flags.append("Pressure / login words in the address: " + ", ".join(kw[:4]))
    if host.count("-") >= 3:
        flags.append(f"Many hyphens in the domain name ({host.count('-')})")
    if not _is_ip(host_nw) and len(host_nw.split(".")) - len(reg.split(".")) >= 3:
        flags.append("Unusually deep chain of subdomains")
    if len(url) >= 120:
        flags.append(f"Very long address ({len(url)} characters)")
    if host_nw in SHORTENERS or reg in SHORTENERS:
        flags.append("Link shortener - the real destination is hidden")
    try:
        if p.port not in (None, 80, 443):
            flags.append(f"Non-standard port ({p.port})")
    except ValueError:
        pass
    if p.scheme == "http":
        flags.append("Not using HTTPS - the connection is not encrypted")
    return flags
