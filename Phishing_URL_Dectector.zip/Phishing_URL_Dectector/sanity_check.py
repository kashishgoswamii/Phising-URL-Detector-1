"""
sanity_check.py - runs the detector on hand-written example URLs and prints a table.

These URLs are NOT in dataset.csv. They are patterns, not live sites:
  expect = 0  -> should be "Likely Safe"
  expect = 1  -> should be "Suspicious / Phishing"

Run:  python sanity_check.py
"""

from detector import analyze_url

SAMPLES = [
    # ---- legitimate -------------------------------------------------------
    ("https://www.flipkart.com/mobiles/smartphones", 0),
    ("https://www.hotstar.com/in/movies/", 0),
    ("https://en.wikipedia.org/wiki/Machine_learning", 0),
    ("https://stackoverflow.com/questions/231767/what-does-the-yield-keyword-do-in-python", 0),
    ("https://www.bbc.com/news/world-asia-india-67891234", 0),
    ("https://docs.python.org/3/library/urllib.parse.html", 0),
    ("https://www.geeksforgeeks.org/python-programming-language-tutorial/", 0),
    ("https://github.com/pallets/flask/issues/4567", 0),
    ("https://accounts.google.com/ServiceLogin?service=mail&continue=https://mail.google.com/mail/", 0),
    ("https://www.amazon.in/gp/css/order-history?ref_=nav_orders_first", 0),
    ("https://onlinesbi.sbi/", 0),
    ("https://www.hdfcbank.com/personal/pay/cards/credit-cards", 0),
    ("https://www.linkedin.com/in/some-student-name-1a2b3c4d/", 0),
    ("https://medium.com/@someone/how-i-learned-to-code-in-six-months-5d1f2a3b4c", 0),
    ("https://www.youtube.com/watch?v=dQw4w9WgXcQ", 0),
    ("https://login.microsoftonline.com/common/oauth2/v2.0/authorize", 0),
    ("https://support.apple.com/en-in/HT201994", 0),
    ("https://www.irctc.co.in/nget/train-search", 0),
    ("https://aktu.ac.in/", 0),
    ("https://www.nytimes.com/2026/11/19/technology/ai-chips-export-rules.html", 0),
    ("https://www.paypal.com/signin", 0),
    ("https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/404", 0),
    ("https://www.swiggy.com/restaurants/dominos-pizza-sector-62-noida-123456", 0),
    ("https://timesofindia.indiatimes.com/india/some-news-story/articleshow/12345678.cms", 0),
    ("https://www.kaggle.com/datasets/uciml/iris", 0),
    # ---- phishing-style ---------------------------------------------------
    ("http://paypal.com.verify-account.tk/login", 1),
    ("https://secure-paypal-login.com/update", 1),
    ("https://paypa1.com/signin", 1),
    ("http://192.168.4.7/paypal/login.php?id=88", 1),
    ("http://45.77.12.9:8080/bank/verify.php", 1),
    ("http://sbi-kyc-update-now.xyz/", 1),
    ("https://netflix-billing-update.com/login", 1),
    ("https://amazon.account-verify.support/signin", 1),
    ("http://hdfc-netbanking-secure.top/login.html", 1),
    ("https://paytm-cashback-claim.click/reward?id=7788", 1),
    ("https://login-microsoft-office365.weebly.com/", 1),
    ("http://appleid-apple.com-verify.info/", 1),
    ("https://g00gle-support.net/recover", 1),
    ("http://facebook.com@evil-site.top/login", 1),
    ("https://xn--pypal-4ve.com/signin", 1),
    ("https://irctc-refund-claim.in/otp/verify", 1),
    ("https://instagram-help-center.web.app/confirm-account", 1),
    ("https://dhl-parcel-tracking.icu/pay?ref=9981", 1),
    ("https://update-your-whatsapp-account.cam/verify", 1),
    ("https://www.secure-bank-alert.xyz/wp-content/x9/login.php?session=ab12cd34ef56", 1),
    ("http://uidai-aadhaar-update.top/kyc", 1),
    ("https://account.google.com.signin-verify.online/v2", 1),
    ("https://free-gift-reward.work/claim", 1),
    ("http://amaz0n-orders.net/confirm", 1),
    ("https://icici-bank-otp-verify.monster/login", 1),
]

# Harder cases. A URL-only model can NOT solve the ones marked [limit]:
# the address alone gives no clue (legit domain abused, hidden destination, brand not known).
HARD_SAMPLES = [
    ("https://www.irs.gov/refunds", 0),
    ("https://paytm.com/offers/cashback-rewards", 0),
    ("https://www.sbicard.com/en/personal/credit-cards/rewards.page", 0),
    ("https://web.archive.org/web/2020*/http://example.com", 0),
    ("https://www.google.com/url?q=https://example.com&sa=D&usg=AOvVaw0", 0),
    ("https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css", 0),
    ("https://secure.checkout.mystore-india.com/cart?id=5", 0),
    ("https://www.chase.com/personal/online-banking", 0),
    ("http://127.0.0.1:5000/", 0),
    ("https://s3.amazonaws.com/my-bucket/report-2026.pdf", 0),
    ("https://www.bankofamerica.com/", 0),
    ("https://www.ebay-login.com/signin", 1),
    ("https://rnicrosoft.com/login", 1),                                   # [limit] look-alike letters 'rn' -> 'm'
    ("https://sites.google.com/view/free-recharge-2026", 1),               # [limit] real domain, abused page
    ("https://docs.google.com/forms/d/e/1FAIpQLSdAbCdEfGh/viewform", 1),   # [limit] real domain, abused page
    ("https://bit.ly/3xYzAbC", 1),                                         # [limit] destination hidden
    ("https://my-account.sbi-online.in/login", 1),
    ("https://qwk3z.top/", 1),
    ("https://sbi.co.in.kyc-update.in/login", 1),
    ("https://secure.bankofamerica.com.auth-session.net/login", 1),
    ("https://paypal.com.account.verify.example.com", 1),
    ("https://www.canarabank-netbanking.in/", 1),
    ("http://myjio-recharge-offer.com/", 1),
]

def run(title, samples):
    wrong = 0
    print(f"\n=== {title} ===")
    print(f"{'':3s} {'risk':>5s}  {'verdict':26s} URL")
    for url, expect in samples:
        a = analyze_url(url)
        got = 1 if a["result"].startswith("Suspicious") else 0
        wrong += got != expect
        print(f"{'OK ' if got == expect else 'XX '} {a['score']:4d}%  {a['result']:26s} {url[:90]}")
    print(f"{len(samples) - wrong}/{len(samples)} correct")


if __name__ == "__main__":
    run("Everyday examples", SAMPLES)
    run("Harder examples", HARD_SAMPLES)
